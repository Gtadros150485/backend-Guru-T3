def api_router():
    return None


def auth():
    return None


def users():
    return None